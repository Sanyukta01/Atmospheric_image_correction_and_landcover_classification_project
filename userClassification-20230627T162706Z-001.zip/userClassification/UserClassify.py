import numpy as np
import rasterio
from rasterio.mask import mask
from skimage import exposure
from skimage.segmentation import slic
from sklearn.ensemble import RandomForestClassifier
import joblib
from osgeo import gdal

# Load the trained model
clf = joblib.load(r"C:\Users\Dell\Desktop\Clipped AP classify\random_forest_model.joblib")

# Load the user image for classification
user_image_fn =  r"C:\Users\Dell\Desktop\Btech_project\Clipped AndhraPradesh_1.tif"
# user_image_fn =  r"C:\Users\Dell\Desktop\trial\Cropped images\CROPimg8.tif"

driverTiff = gdal.GetDriverByName('GTiff')
user_ds = gdal.Open(user_image_fn)
nbands = user_ds.RasterCount
band_data = []
for i in range(1, nbands+1):
    band = user_ds.GetRasterBand(i).ReadAsArray()
    band_data.append(band)
band_data = np.dstack(band_data)
# scale image values from 0.0 - 1.0
img = exposure.rescale_intensity(band_data)

# Perform image segmentation
segments = slic(img, n_segments=5000, compactness=0.1)

print("segmented img")
import scipy
def segment_features(segment_pixels):
    features = []
    npixels, nbands = segment_pixels.shape
    for b in range(nbands):
        stats = scipy.stats.describe(segment_pixels[:, b])
        band_stats = list(stats.minmax) + list(stats)[2:]
        if npixels == 1:
            # in this case the variance = nan, change it 0.0
            band_stats[3] = 0.0
        features += band_stats
    return features

# Extract object features from the segmented image
segment_ids = np.unique(segments)
objects = []
for id in segment_ids:
    segment_pixels = img[segments == id]
    object_features = segment_features(segment_pixels)
    objects.append(object_features)


# Use the trained model to classify the objects in the image
predicted_labels = clf.predict(objects)

# Create a classification map by assigning the predicted label to each segment
classification_map = np.zeros_like(segments)
for i, segment_id in enumerate(segment_ids):
    classification_map[segments == segment_id] = predicted_labels[i]

# Save the classification map to a raster file
classification_fn = r'C:\Users\Dell\Desktop\Userclassif_raster.tif'

with rasterio.open(user_image_fn) as src:
    profile = src.profile
    profile.update(dtype=rasterio.float32, count=1)
    with rasterio.open(classification_fn, 'w', **profile) as dst:
        dst.write(classification_map.astype(rasterio.float32), 1)
print('Classification map saved to', classification_fn)
