#RK

import rasterio
from osgeo import gdal
from matplotlib import pyplot as plt
import numpy as np

def scaleCCC(x):
    return((x - np.nanpercentile(x, 2))/(np.nanpercentile(x, 98) - np.nanpercentile(x,2)))

# Open the 12-band TIF image
ds = gdal.Open(r"C:\Users\Dell\Desktop\Btech_project\reconstructed_image.tif")
r = ds.GetRasterBand(4).ReadAsArray()
g = ds.GetRasterBand(3).ReadAsArray()
b = ds.GetRasterBand(2).ReadAsArray()

ds = None

rCCC = scaleCCC(r)
gCCC = scaleCCC(g)
bCCC = scaleCCC(b)

rgbCCC = np.dstack((rCCC,gCCC,bCCC))

# Display the RGB image
plt.figure()
plt.title("Click on the image to get center coordinates of region of interest for classification")
plt.imshow(rgbCCC)

# Wait for the user to click on the image
x, y = plt.ginput(1)[0]

# Print the coordinates of the clicked location
print("Clicked location: ({:.2f}, {:.2f})".format(x, y))

# Retrieve the pixel values at the clicked location
with rasterio.open(r"C:\Users\Dell\Desktop\Btech_project\reconstructed_image.tif") as src:
    row, col = src.index(x, y)
    pixel_values = src.read(window=((row, row+1), (col, col+1)))


from osgeo import gdal

# Open the input file
input_file = gdal.Open(r"C:\Users\Dell\Desktop\Btech_project\reconstructed_image.tif", gdal.GA_ReadOnly)
# input_file = gdal.Open(r"C:\Users\Dell\Pictures\CWPRS dataset images\clear img\Jharkhand_6_2022-04-02_2A.tif", gdal.GA_ReadOnly)
# Get the geotransform and projection information
geotransform = input_file.GetGeoTransform()
projection = input_file.GetProjection()

# Define the size of the output image
crop_width = 1576
crop_height = 833

# Get user-specified coordinates as the center of the cropped portion
center_x = x
center_y = y

# Calculate upper left corner of cropped portion based on input coordinates and output size
x_offset = int(center_x - (crop_width / 2))
y_offset = int(center_y - (crop_height / 2))

# Define the output file name and format
output_file = r'C:\Users\Dell\Desktop\UserCropfinal.tif'
driver = gdal.GetDriverByName("GTiff")

# Use gdal.Warp to create the output file with the cropped portion
output = driver.Create(output_file, crop_width, crop_height, input_file.RasterCount, input_file.GetRasterBand(1).DataType)
output.SetGeoTransform((geotransform[0] + (x_offset * geotransform[1]), geotransform[1], 0, geotransform[3] + (y_offset * geotransform[5]), 0, geotransform[5]))
output.SetProjection(projection)
gdal.Warp(output, input_file, outputBounds=[geotransform[0] + (x_offset * geotransform[1]), geotransform[3] + (y_offset * geotransform[5]), geotransform[0] + ((x_offset + crop_width) * geotransform[1]), geotransform[3] + ((y_offset + crop_height) * geotransform[5])], format="GTiff", srcNodata=-9999, dstNodata=-9999)

# Open the output file and get its size
output_file = gdal.Open(output_file)
output_height, output_width = output_file.RasterYSize, output_file.RasterXSize
print("Output image size: ", output_height, "x", output_width)

# Close the input and output files
input_file = None
output_file = None
