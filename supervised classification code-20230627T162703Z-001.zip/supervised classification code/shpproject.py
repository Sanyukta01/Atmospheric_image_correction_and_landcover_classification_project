import numpy as np
import geopandas as gpd
import pandas as pd

# read shapefile to geopandas geodataframe
gdf = gpd.read_file(r"C:\Users\sanyu\Documents\cropedimg.shp")
# get names of land cover classes/labels
class_names = gdf['class'].unique()
print('class names', class_names)
# create a unique id (integer) for each land cover class/label
class_ids = np.arange(class_names.size) + 1
print('class ids', class_ids)
# create a pandas data frame of the labels and ids and save to csv
df = pd.DataFrame({'classs': class_names, 'id': class_ids})
df.to_csv(r"C:\Users\sanyu\Documents\class_lookup.csv")
print('gdf without ids\n', gdf.head())
# add a new column to geodatafame with the id for each class/label
gdf['id'] = gdf['class'].map(dict(zip(class_names, class_ids)))
print('gdf with ids\n', gdf.head())

# split the truth data into training and test data sets and save each to a new shapefile
gdf_train = gdf.sample(frac=0.7)
gdf_test = gdf.drop(gdf_train.index)
print('gdf shape', gdf.shape, 'training shape', gdf_train.shape, 'test', gdf_test.shape)
gdf_train.to_file(r'C:\Users\sanyu\Documents\train.shp')
gdf_test.to_file(r'C:\Users\sanyu\Documents\test.shp')